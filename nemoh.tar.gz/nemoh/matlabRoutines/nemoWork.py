# -*- coding: utf-8 -*-
"""
Created on Tue Nov 18 22:43:38 2014

@author: mlawson
"""
import meshio as mio
import nemohio as nio
import wamitio as wio
import os
import vtk
import numpy as np

nmesh = mio.readNemohMesh('/Users/mlawson/Applications/nemoh/matlabRoutines/nonsymmetrical/NonSymmetrical.dat')


nemOrig = nio.Nemoh(directory='/Users/mlawson/Applications/nemoh/matlabRoutines/nonsymmetrical',name='.')
nemOrig.results.readCMCA()
nemOrig.results.plotAddedMassAndDamping()

nemMe = nio.Nemoh(directory='/Users/mlawson/Applications/nemoh/matlabRoutines/nonsymmetrical-me',name='.')
nemMe.results.readCMCA()
nemMe.results.plotAddedMassAndDamping()


#mesh = mio.readNemohMesh('/Users/mlawson/Applications/nemoh/matlabRoutines/nonsymmetrical-osx/NonSymmetrical.dat')
#mesh.writeVtp('/Users/mlawson/Applications/nemoh/matlabRoutines/nonsymmetrical-osx/NonSymmetrical.vtp')
#mesh.writeGdf('/Users/mlawson/Applications/nemoh/matlabRoutines/nonsymmetrical-wamit/skewed-sphere.GDF')
#
#pyMesh = mio.readVtp('/Users/mlawson/Applications/nemoh/matlabRoutines/nonsymmetrical-osx/NonSymmetrical.vtp')
#py = nio.Nemoh(simDir='/Users/mlawson/Applications/nemoh/matlabRoutines/nonsymmetrical-py')
#py.mesh = mesh
##py.waveFreq = [41,      0.1,     2.0]
##py.waterDepth = 0
##py.runNemohPreProc()
##py.runNemoh()
##py.runNemohPostProc()
#py.results.readCMCA()
#py.results.plotAddedMassAndDamping()
#
#wamit = wio.WamitOutput(directory='/Users/mlawson/Applications/nemoh/matlabRoutines/nonsymmetrical-wamit',simName='skewed-shpere')
#wamit.plotAddedMassAndDamping()